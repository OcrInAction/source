/**
 * 
 */
package it.book.ocr.in.azione;

import java.io.File;
import net.sourceforge.tess4j.*;
/**
 * @author 
 *
 */
public class MyExampleTess4J {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		File imageFile = new File("C:\\appoggio\\Tips\\ocr-text_analysis\\Tesseract-Ocr\\API\\Tess4J-1.1-src\\Tess4J\\eurotext.tif");
        Tesseract instance = Tesseract.getInstance();  // JNA Interface Mapping
        //Tesseract1 instance = new Tesseract1(); // JNA Direct Mapping

        instance.setLanguage("deu+spa+por+eng");
        
        try {
            String result = instance.doOCR(imageFile);
            System.out.println(result);
        } catch (TesseractException e) {
            System.err.println(e.getMessage());
        }		
		
		
	}

}
